<footer>
    <div class="footer-section d-flex flex-column flex-wrap justify-content-center text-center px-2 py-3">
        <?php dynamic_sidebar( 'footer' ); ?>
        </span>
    </div>
    </footer> 
<?php wp_footer(); ?>
</body>